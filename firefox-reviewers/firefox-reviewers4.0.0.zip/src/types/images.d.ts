declare module "*.png" {
  const src: string;
  export default src;
}
