import { useAppConfig } from "#imports";

console.log(useAppConfig()); // { theme: "dark" }
