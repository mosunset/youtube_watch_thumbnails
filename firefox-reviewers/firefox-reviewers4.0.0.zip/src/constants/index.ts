// 集約された定数定義（DRY）

export const repoUrl = "https://github.com/mosunset/youtube_watch_thumbnails";
export const homepageUrl = "https://mosunset.com";

export const STORAGE_KEY = "youtube_video_id";
