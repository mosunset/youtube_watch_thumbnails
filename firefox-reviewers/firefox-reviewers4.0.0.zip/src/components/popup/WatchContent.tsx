import UrlDisplay from "./UrlDisplay";

function WatchContent({ url }: { url: string }) {
    return <UrlDisplay url={url} />;
}

export default WatchContent;
