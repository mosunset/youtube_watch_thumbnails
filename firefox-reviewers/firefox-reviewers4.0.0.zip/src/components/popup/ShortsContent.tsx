import UrlDisplay from "./UrlDisplay";

function ShortsContent({ url }: { url: string }) {
    return <UrlDisplay url={url} />;
}

export default ShortsContent;
